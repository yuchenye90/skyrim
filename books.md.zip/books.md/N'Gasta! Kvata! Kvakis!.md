N'Gasta! Kvata! Kvakis!

　　这是用斯洛德语写的一段异常晦涩的文字，作者据称是第二纪元来自西方的亡灵法师恩伽斯塔。
　　
　　N'Gasta! Kvata! Kvakis! ahkstas so novajxletero (oix jhemile)  so Ranetauw. Ricevas gxin pagintaj membrauw kaj aliaj individuauw, kiujn iamaniere tusxas so raneta aktivado. En gxi aperas informauw unuavice pri so lokauw  so cxiumonataj kunvenauw, sed nature ankoix pri aliaj aktuasoj aktivecauw so societo. Ne malofte enahkstas krome plej diversaspekta materialo eduka oix distra.
　　So interreta Kvako (retletera kaj verjheauw) ahkstas unufsonke alternativaj kanasouw por distribui so enhavon  so papera Kva! Kvak!. Sed alifsonke so enhavauw  so diversaj verjheauw antoixvible ne povas kaj ecx ne vus cxiam ahksti centprocente so sama. En malvaste cirkusonta paperfolio ekzemple ebsos publikigi ilustrajxauwn, kiuj pro kopirajtaj kiasouw ne ahkstas uzebsoj en so interreto. Alifsonke so masoltaj kostauw reta distribuo forigas so spacajn limigauwn kaj permahksas pli ampleksan enhavon, por ne paroli pri gxishora aktualeco.
　　Tiuj cirkonstancauw rahkspeguligxos en so aspekto so Kvakoa, kiu ja cetere servos ankoix kiel gxeneraso retejo so ranetauw.

　　【经考证，这篇文章是用西班牙语写成，然后制作者将一些字符用其他的替换过来。
　　替换码如下：
　　ahk - e
　　oix - aux
　　so - la
　　auw - oj
　　jhe - si
　　翻译过来的英文原文如下：

　　Kva! Kvak! is the newsletter of the La Ranetoj. It is send to paying members and other individuals who, in some way, are involved in la Ranetoj's activities. In it there firstly is information about the locations of the monthly meetings, but of course also concerning the latest activities of the club. Sometimes it also includes other educating or entertaining material.
　　The Internet-based Kvako are on the one hand another distribution channel for the contents of the paper version. But on the other hand, not surprisingly, the contents of the different versions cannot and even must not always be 100 percent the same. For instance, in little circulating paper versions you can publish illustrations that, for copyright reasons, cannot be used on the Internet. Yet on the other hand the low costs of the Internet version lift the space limits and allow more content, not to mention being always to date.
　　These circumstances influence the web-based Kvako, which will also serve as the general homepage of the 'La Ranetoj'.
　　
　　中文如下：
　　
　　Kva! Kvak!是“小青蛙社”的刊物。社团将这份刊物送给那些付会费的会员和其他在某种意义上与“小青蛙社”的活动有所关联的人。刊物里首先刊载的是社团每个月的会面地点，当然也有最新的活动的情况报道。有时候还会包括其他的教育性或是娱乐性的内容。
　　
　　一方面，作为纸张版本的Kvako的延展，网络版的Kvako扩大了新闻内容的传播渠道。另一方面，这两个不同版本的内容通常也不尽相同，而这也不足为奇。举例说，在小范围发放的纸张版本中，可以采用一些由于版权问题而不能刊登在网上的图片。然而网络版价格低廉，创作空间充足，可以加入更多的内容，而且能够随时更新。
　　
　　以上情况都影响到网络版的Kvako的运作，而它同时也作为“小青蛙社”的主页来使用。】